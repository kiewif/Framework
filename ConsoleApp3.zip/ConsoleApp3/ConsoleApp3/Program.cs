﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    public class SortingFramework
    {
        static void Main(string[] args)
        {           
            TestSelectionSort();
            TestMergeSort();
            TestInsertionSort();
            Console.ReadLine();
        }
        
        //Merge Sort Test
        public static void TestMergeSort()
        {
            int[] input = new int[] { 1, 10, 5, 2, 7, 8, 200, 99, 4, 62, 10, 12 };

            DoMergeSort(input);
            foreach(int number in input)
            {
                Console.Write(number + " ");               
            }           
        }
        //Selection Sort Test
        public static void TestSelectionSort()
        {
            int[] input = new int[] { 1, 10, 5, 2, 7, 8, 200, 99, 4, 62, 10, 12 };

            SelectionSort(input);
            foreach (int number in input)
            {
                Console.Write(number + " ");
            }
            
        }
        //Insertion Sort Test
        public static void TestInsertionSort()
        {
            int[] input = new int[] { 1, 10, 5, 2, 7, 8, 200, 99, 4, 62, 10, 12 };

            InsertionSort(input);
            foreach (int number in input)
            {
                Console.Write(number + " ");
            }
        }


        //-----------Selection Sort Algorithm--------------------
        public static int[] SelectionSort(int[] array)
        {
            for (int i =0; i<array.Length-1; i++)
            {
                int currentMin = i;
                for(int j =i+1; j<array.Length; j++)
                {
                    if (array[j] < array[currentMin])
                    {
                        currentMin = j;
                    }
                }
                //Swap
                int temp = array[i];
                array[i] = array[currentMin];
                array[currentMin] = temp;
            }
            return array;
        }

        //------------Insertion Sort Algorithm--------------
        public static int[] InsertionSort(int[] array)
        {
            for (int i =1; i< array.Length; i++)
            {
                int value = array[i];
                int j = i - 1;
                while (j >= 0 && array[j] > value)
                {
                    array[j + 1] = array[j];
                    j--;
                }
                array[j + 1] = value;
            }
            return array;
        }

        //-------------Merge Sort Algorithm---------------

        public static void DoMergeSort(int[] numbers)
        {
            var sortedNumbers = MergeSort(numbers);

            for(int i=0; i <sortedNumbers.Length; i++)
            {
                numbers[i] = sortedNumbers[i];
            }
        }

        public static int[] MergeSort(int[] array)
        {        
            if (array.Length <= 1)
            {
                return array; //base case
            }

            var leftside = new List<int>();
            var rightside = new List<int>();

            for( int i = 0; i<array.Length; i++)
            {
                if(i%2 == 0) //split into 2 equal size arrays - odd and even
                {
                    leftside.Add(array[i]);
                }
                else
                {
                    rightside.Add(array[i]);
                }
            }
            leftside = MergeSort(leftside.ToArray()).ToList();
            rightside = MergeSort(rightside.ToArray()).ToList();
            
            return Merge(leftside, rightside);
        }

        //Sorts individual sides of array in to a result List
        public static int[] Merge(List<int> leftside, List<int> rightside)
        {
            var result = new List<int>();
            while (NotEmpty(leftside) && NotEmpty(rightside)) //both arrays non-empty
            {
                if (leftside[0] <= rightside[0])
                {
                    SourceToResult(leftside, result);
                }
                else
                {
                    SourceToResult(rightside, result);
                }
            }
            //Either left or right not empty, sort in to result
            while (NotEmpty(leftside))
            {
                SourceToResult(leftside, result);
            }
            while (NotEmpty(rightside))
            {
                SourceToResult(rightside, result);
            }
            return result.ToArray();
        }

        //Check if a list is empty
        private static bool NotEmpty(List<int> list)
        {
            return list.Count > 0;
        }

        //Moves item from input list to result variable, and removes item from list
        private static void SourceToResult(List<int> list, List<int> result)
        {
            result.Add(list[0]);
            list.RemoveAt(0);
        }

    }

}
