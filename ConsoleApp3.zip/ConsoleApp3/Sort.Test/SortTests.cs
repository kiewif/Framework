﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Sort.Test
{
    [TestClass]
    public class SortTests
    {
        public static int[] input = new int[] { 1, 10, 5, 2, 7, 8, 200, 99, 4, 62, 10, 12 };
        public static int[] expected = new int[] { 1, 2,4,5,7,8,10,10,12,62,99,200};

        [TestMethod]      
        public static void TestMergeSort()
        {
            ConsoleApp3.SortingFramework.DoMergeSort(input);
            Assert.AreEqual(input, expected);
        }

        [TestMethod]
        public static void TestSelectionSort()
        {
            ConsoleApp3.SortingFramework.SelectionSort(input);
            Assert.AreEqual(input, expected);
        }

        [TestMethod]
        public static void TestInsertionSort()
        {
            ConsoleApp3.SortingFramework.InsertionSort(input);
            Assert.AreEqual(input, expected);
        }
    }
}
